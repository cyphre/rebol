Magick Extension sources

project Visual Studio 2003

libs generated from ImageMagick-6.6.5-8-Q16 sources
incude files from from ImageMagick-6.6.5-8-Q16 and R3-a110

tested under Windows XP, with R3-a110, ImageMagick 6.6.5, and Ghostscript 8.61

To use this extension you need to:
- install the ImageMagick runtime (ImageMagick-6.6.5-8-Q16-windows-dll.exe)
- register the ImageMagickObject dll : regsvr32 ImageMagickObject.dll
- in case of using pdf format, install Ghostscript http://pages.cs.wisc.edu/~ghost/