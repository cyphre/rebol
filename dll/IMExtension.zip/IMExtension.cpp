/***********************************************************************
**
**  REBOL Invasion 3.0
**
**  simple REBOL Extension for ImageMagick
**	J. Colineau 2009-2010
**
** NB: uses ImageMagickObject (a windows COM component)
** a version for Linux should use MagickCommandGenesis() instead
**
***********************************************************************/

#define ODD_INT_64
#define UNICODE

#define REB_EXT 
#define TO_WIN32


#include "reb-c.h"
#include "reb-ext.h"
#include "reb-args.h"
#include "reb-device.h"
#include "reb-event.h"
#include "reb-lib.h"

#include "StdAfx.h"

#include <shellapi.h>

#include <iostream>
#include <atlbase.h>
#include <atlsafe.h>
#import "ImageMagickObject.tlb" no_namespace

#include "magick/MagickCore.h"
#include "wand/studio.h"
#include "wand/MagickWand.h"


#define ThrowWandException(wand) { char  *description; ExceptionType  severity; description=MagickGetException(wand,&severity);(void) fprintf(stderr,"%s %s %lu %s\n",GetMagickModule(),description);description=(char *) MagickRelinquishMemory(description); ;}


typedef enum
{
	cmdUnknown,
	cmdCompare,
	cmdComposite,
	cmdConvert,
	cmdIdentify,
	cmdMogrify,
	cmdMontage,
	cmdStream
} CommandType;

static struct
Commands
{
	LPCTSTR name;
	CommandType code;
} Commands[] =
{
	{ _T(""),          cmdUnknown   },
	{ _T("compare"),   cmdCompare   },
	{ _T("composite"), cmdComposite },
	{ _T("convert"),   cmdConvert   },
	{ _T("identify"),  cmdIdentify  },
	{ _T("mogrify"),   cmdMogrify   },
	{ _T("montage"),   cmdMontage   },
	{ _T("stream"),    cmdStream   }
};


int do_cmd(int argc, TCHAR* argv[])
{
	int
		index,
		status = 0;

	LPCTSTR
		name;

	CommandType
		code = cmdUnknown;

	index = 0;
	while ((name = Commands[index].name))
	{
		if (_tcsicmp(name,argv[0]) == 0)
		{
			code = Commands[index].code;
			break;
		}
		index++;
	}
	if (code == cmdUnknown)
		return 0;

//	CoInitialize(NULL);



	try
	{
		CComVariant
			result;

		SAFEARRAY
			**ppsa = (SAFEARRAY**) NULL;

		IMagickImagePtr pImageProc(__uuidof(MagickImage));
		if (pImageProc == NULL)
		{
			status = 1;
		}
		else
		{
			{
				// Define the array bound structure
				CComSafeArrayBound bound[1];
				bound[0].SetCount(argc-1);
				bound[0].SetLowerBound(0);
				CComSafeArray<VARIANT> args(bound);
				if( !args )
					status = 2;
				else
				{

					for(index = 1; index < argc; ++index)
					{
						CComVariant vt(argv[index]);
						HRESULT hr = vt.Detach(&args[index-1]);
					}

					switch(code)
					{
					case cmdCompare:
						result = pImageProc->Compare(args.GetSafeArrayPtr());
						break;
					case cmdComposite:
						result = pImageProc->Composite(args.GetSafeArrayPtr());
						break;
					case cmdConvert:
						result = pImageProc->Convert(args.GetSafeArrayPtr());
						break;
					case cmdIdentify:
						result = pImageProc->Identify(args.GetSafeArrayPtr());
						break;
					case cmdMogrify:
						result = pImageProc->Mogrify(args.GetSafeArrayPtr());
						break;
					case cmdMontage:
						result = pImageProc->Montage(args.GetSafeArrayPtr());
						break;
					case cmdStream:
						result = pImageProc->Stream(args.GetSafeArrayPtr());
						break;
					}
					pImageProc.Release();
				}
			}
		}
	}
	catch(_com_error ex)
	{
		HRESULT res = ex.Error();  
		_bstr_t desc = ex.Description();  
		_ftprintf( stderr, _T("Error %ws (0x%08x)\n"), (wchar_t*)desc , res );
		status = 4;
	}

//	CoUninitialize();
	return status;
}


//--- debut code standard extension ---

enum command_nums {
	CMD_IM,
	CMD_IMSAVE,
	CMD_IMLOAD,
	CMD_IMTEST,
};

const char *init_block =
"REBOL [\n"
" title: {Image Magick extension}\n"
" type: module\n"
" options: [extension]\n"
"]\n"
"export Magick: command [{Image Magick command-line Interpreter} str [string!]]\n"
"export Magick-save: command [{Saves an image} img [image!] str [string!]]\n"
"export Magick-load: command [{Returns an image} str [string!]]\n"
;

RL_LIB *RL;


RXIEXT const char *RX_Init(int opts, RL_LIB *lib) {
	RL = lib;
	//	if ((sizeof(RXIARG) != 8 ) || (lib->version != RL_VERSION))  //RXI_VERSION) 
	//		return 0;
	MagickWandGenesis();
	CoInitialize(NULL);
	return init_block;
}

RXIEXT int RX_Quit(int opts) {
	CoUninitialize();
	MagickWandTerminus();
	return 0;
}

RXIEXT int RX_Call(int cmd, RXIFRM *frm, void *data) {
	switch (cmd) {

	case CMD_IM:
		{
			if (FAILED(::CoInitialize(NULL)))
				return RXR_FALSE;

			// initialisation de Magick avec le path de l'exe ...
			// InitializeMagick(*argv);  // *argv) = argv[0]

			REBCHR *s = (REBCHR *)RL_MAKE_STRING(1000,true);
			REBSER *ss = (REBSER *)RXA_SERIES(frm, 1);
			i32 idx = RXA_INDEX(frm, 1);
			RL_GET_STRING(ss,idx,(void **)&s);

			LPSTR lpszArgument = (LPSTR)s;

			size_t cmdSize = 0;
			wchar_t* wcmdLine = NULL;
			LPWSTR* argv = NULL;
			int argc = 0;
			int arg1 = 0;
			int arg2 = 0;

			cmdSize = strlen(lpszArgument)+1;
			wcmdLine = (wchar_t* ) malloc(cmdSize * sizeof(wchar_t));

			MultiByteToWideChar( CP_ACP, 0, lpszArgument, cmdSize, wcmdLine, (cmdSize * sizeof(wchar_t)) );
			argv = CommandLineToArgvW(wcmdLine, &argc);

			do_cmd(argc, argv);

			LocalFree(argv);
			free(wcmdLine);

		}
		break;
	case CMD_IMSAVE:
		{
			REBYTE * imgIn = 0;
			REBSER* im;
			REBINT imgInWidth;
			REBINT imgInHeight;
			if (RXA_TYPE(frm,1)==RXT_IMAGE){
				im = (REBSER *)RXA_IMAGE(frm,1);
				imgIn = (REBYTE *)RL_SERIES(im, RXI_SER_DATA);
				imgInWidth = RXA_IMAGE_WIDTH(frm,1);
				imgInHeight = RXA_IMAGE_HEIGHT(frm,1);
				// printf("width %i  height %i \n",imgInWidth , imgInHeight);
			}

			REBCHR *outPtrName = (REBCHR *)RL_MAKE_STRING(1000,true);
			REBSER *s2 = (REBSER *)RXA_SERIES(frm, 2);
			i32 idx = RXA_INDEX(frm, 2);
			idx = 0;
			RL_GET_STRING(s2,idx,(void **)&outPtrName);
			// printf("outPtrName %s\n",outPtrName);
			
			MagickWand *canvas = (MagickWand *)NULL;
			MagickBooleanType status;
			// MagickWandGenesis();
			canvas=NewMagickWand();
			PixelWand *pixel = NewPixelWand();
			MagickNewImage(canvas,imgInWidth,imgInHeight,pixel);
			status = MagickImportImagePixels( canvas, 0, 0, imgInWidth, imgInHeight, "BGRO", CharPixel,(char *) imgIn );
			if (status == MagickFalse)
				   ThrowWandException(canvas);
			
			status = MagickWriteImage(canvas,(char *)outPtrName);
			if (status == MagickFalse)
				   ThrowWandException(canvas);

			ClearPixelWand(pixel);
			pixel = DestroyPixelWand(pixel);
			ClearMagickWand(canvas);
			canvas =DestroyMagickWand( canvas );
			//MagickWandTerminus();
			return RXR_TRUE;
		}
	case CMD_IMLOAD:
		{

			REBCHR *inPtrName = (REBCHR *)RL_MAKE_STRING(1000,true);
			REBSER *s1 = (REBSER *)RXA_SERIES(frm, 1);
			i32 idx = RXA_INDEX(frm, 1);
			RL_GET_STRING(s1,idx,(void **)&inPtrName);
			// printf("inPtrName %s\n",inPtrName);

			// --------------
			MagickWand *canvas = (MagickWand *)NULL;
			MagickBooleanType status;
			// MagickWandGenesis();
			canvas=NewMagickWand();

			status=MagickReadImage( canvas, (char *) inPtrName);
			if (status == MagickFalse)
				   ThrowWandException(canvas);

			int imgOutWidth = MagickGetImageWidth(canvas);
			int imgOutHeight = MagickGetImageHeight(canvas);

			REBSER* im;
			REBYTE* imgOut = 0;
			im = (REBSER*) RL_MAKE_IMAGE(imgOutWidth,imgOutHeight);
			imgOut = (REBYTE *)RL_SERIES(im, RXI_SER_DATA);

			status = MagickExportImagePixels ( canvas, 0, 0, imgOutWidth, imgOutHeight, "BGRO", CharPixel,(char *) imgOut ); 

			 if (status == MagickFalse)
			   ThrowWandException(canvas);

			ClearMagickWand(canvas);
			canvas =DestroyMagickWand( canvas );
			// MagickWandTerminus();

			RXA_IMAGE(frm,1) = im;
			RXA_IMAGE_WIDTH(frm,1) = imgOutWidth;
			RXA_IMAGE_HEIGHT(frm,1) = imgOutHeight;
			RXA_TYPE(frm,1)  = RXT_IMAGE;
			return RXR_VALUE;
		}

	default:
		return RXR_NO_COMMAND;
	}

	return RXR_TRUE;
}


