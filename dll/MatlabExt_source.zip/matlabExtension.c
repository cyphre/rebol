/***********************************************************************
**
**  REBOL Invasion 3.0
**
**	Matlab REBOL Extension
**  J. Colineau 2009-2010
**
***********************************************************************/

#define ODD_INT_64

// modif JC 6/11/2010
#define REB_EXT 
#define TO_WIN32


#include "reb-c.h"
#include "reb-ext.h"

#include "reb-args.h"
#include "reb-device.h"
#include "reb-event.h"
#include "reb-lib.h"

#include "engine.h"
#include <string.h>

#define  M_OK 1
#define  M_FAIL 0
#define  BUFSIZE 256
#define  VERSION "0.3.0"

static 	Engine *ep;
static char buffer[BUFSIZE+1];
REBSER *ss;
int i;

// u32 *word_ids = 0; // used to hold word identifiers
RL_LIB *RL;

const char *init_block =
    "REBOL [\n"
	"title: {Matlab Extension}\n"
	"name: Matlab-ext\n"
	"type: module\n"
	"options: [extension]\n"
"]\n"
"export Matlab-Start: command [{start Matlab Engine}]\n"
"export Matlab-Stop: command [{stop Matlab Engine}]\n"
"export Matlab: command [{extension for Matlab Engine} str [string!]]\n"
;


int MatlabStart(void){
			if (!(ep = engOpen("\0"))) {
				return M_FAIL;}
			else return M_OK;
}

int MatlabStop(void){
			int res = 1;
			if (ep) res = engClose(ep);
			ep = NULL ;
			if (res==1) return M_FAIL;
			else return M_OK;
}


int MatlabEval(char* str){  
	if (ep == NULL) {
		if (MatlabStart() != M_OK)	return M_FAIL;
		}
	buffer[BUFSIZE] = '\0';
	engOutputBuffer(ep, buffer, BUFSIZE);
	engEvalString(ep, str); 
	return M_OK;
}

RXIEXT const char *RX_Init(int opts, RL_LIB *lib) {
	RL = lib;
//	if (sizeof(RXIARG) != 8 || lib->version != RXI_VERSION)
//		return 0;
	return init_block;
}


RXIEXT int RX_Quit(int opts) {
	//MatlabStop();
	return 0;
}

RXIEXT int RX_Call(int cmd, RXIFRM *frm, void* data) {
	switch (cmd) {
	case 0:
		if (!MatlabStart())
		return RXR_FALSE;		
		break;
	case 1:
		if (!MatlabStop())
		return RXR_FALSE;
		break;
	case 2:
		{
		// version pour a102
		REBSER *s = (REBSER *)RL_MAKE_STRING(1000, 0); // essayer true, false
		REBSER *si = (REBSER *)RXA_SERIES(frm, 1);
		i32 idx = RXA_INDEX(frm, 1);
		RL_GET_STRING(si,idx,(void **)&s);
		MatlabEval((char *)s);
		ss = RL_MAKE_STRING(BUFSIZE+1, 0);
		for (i =0;i<strlen(buffer);i++) { 
				RL_SET_CHAR(ss,i,buffer[i]);
			}
		RXA_SERIES(frm, 1) = ss;
		RXA_INDEX(frm, 1) = 0;
		RXA_TYPE(frm, 1) = RXT_STRING;
		}
		break;
	default:
		return RXR_NO_COMMAND;
	}
	return RXR_VALUE;
}
