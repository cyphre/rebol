for R3 A102+

tested under Windows 2000 SP4, with Matlab 7.0.1 (R14)
and Windows XP, with Matlab 7.5.0 (R2007b)